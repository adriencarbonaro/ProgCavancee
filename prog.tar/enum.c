#include <stdio.h>

int main()
{
	enum enumTest{FOO=3,BAR=2,MYSTERY};
	return 0;
}
