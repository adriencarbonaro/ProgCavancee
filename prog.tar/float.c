#include <stdio.h>

int main()
{
	double floatVar = 7558963.25;
	printf("num=%f\n", floatVar);
	return 0;
}
