#include <stdio.h>
#include <string.h>

int main()
{
	char foo[3];
	strcpy(foo, "weiner");
	printf("foo=%s\n", foo);
	return 0;
}
