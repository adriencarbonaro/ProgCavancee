#include <stdio.h>

int main()
{
	int myarray[5]={1,1,1,1,1};
	myarray[6]=1;
	printf("%d \n", myarray[6]);
	return 0;
}
